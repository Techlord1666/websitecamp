"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Menu, X, Star, Check, MessageCircle, Code, Palette, Zap, Users, Award, Clock } from "lucide-react"

export default function LandingPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <div className="min-h-screen bg-white overflow-hidden">
      {/* Navigation */}
      <nav className="relative z-50 bg-white/90 backdrop-blur-md border-b border-gray-100 sticky top-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-green-500 bg-clip-text text-transparent">
                  WebBootcamp
                </h1>
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <a
                  href="#"
                  className="text-gray-900 hover:text-blue-600 px-3 py-2 text-sm font-medium transition-colors"
                >
                  Home
                </a>
                <a
                  href="#about"
                  className="text-gray-600 hover:text-blue-600 px-3 py-2 text-sm font-medium transition-colors"
                >
                  About
                </a>
                <a
                  href="#courses"
                  className="text-gray-600 hover:text-blue-600 px-3 py-2 text-sm font-medium transition-colors"
                >
                  Courses
                </a>
                <a
                  href="#"
                  className="text-gray-600 hover:text-blue-600 px-3 py-2 text-sm font-medium transition-colors"
                >
                  Testimonials
                </a>
                <Button
                  className="bg-green-500 hover:bg-green-600 text-white"
                  onClick={() => window.open("https://chat.whatsapp.com/E5Eg0Nnpawe6ISmai3kMdf", "_blank")}
                >
                  Enroll Now
                </Button>
              </div>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <Button variant="ghost" size="sm" onClick={() => setIsMenuOpen(!isMenuOpen)}>
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <a href="#" className="block px-3 py-2 text-base font-medium text-gray-900">
                Home
              </a>
              <a href="#about" className="block px-3 py-2 text-base font-medium text-gray-600">
                About
              </a>
              <a href="#courses" className="block px-3 py-2 text-base font-medium text-gray-600">
                Courses
              </a>
              <a href="#" className="block px-3 py-2 text-base font-medium text-gray-600">
                Testimonials
              </a>
              <Button
                className="w-full mt-2 bg-green-500 hover:bg-green-600 text-white"
                onClick={() => window.open("https://chat.whatsapp.com/E5Eg0Nnpawe6ISmai3kMdf", "_blank")}
              >
                Enroll Now
              </Button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-green-50">
        {/* Floating Icons */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div
            className={`absolute top-20 left-10 transform transition-all duration-1000 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}
          >
            <div className="bg-white p-4 rounded-2xl shadow-lg transform rotate-12 hover:rotate-6 transition-transform duration-300">
              <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">W</span>
              </div>
            </div>
          </div>

          <div
            className={`absolute top-32 right-16 transform transition-all duration-1000 delay-200 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}
          >
            <div className="bg-white p-4 rounded-2xl shadow-lg transform -rotate-12 hover:rotate-6 transition-transform duration-300">
              <div className="w-12 h-12 bg-orange-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">Wix</span>
              </div>
            </div>
          </div>

          <div
            className={`absolute bottom-32 left-20 transform transition-all duration-1000 delay-400 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}
          >
            <div className="bg-white p-4 rounded-2xl shadow-lg transform rotate-6 hover:-rotate-6 transition-transform duration-300">
              <Code className="w-12 h-12 text-gray-700" />
            </div>
          </div>

          <div
            className={`absolute top-40 left-1/2 transform transition-all duration-1000 delay-600 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"}`}
          >
            <div className="bg-white p-4 rounded-2xl shadow-lg transform -rotate-6 hover:rotate-12 transition-transform duration-300">
              <Palette className="w-12 h-12 text-green-500" />
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div
              className={`transform transition-all duration-1000 ${isVisible ? "translate-x-0 opacity-100" : "-translate-x-10 opacity-0"}`}
            >
              <Badge className="mb-6 bg-green-100 text-green-700 hover:bg-green-100">🚀 No Coding Required</Badge>
              <h1 className="text-4xl md:text-6xl font-bold text-gray-900 leading-tight mb-6">
                Learn to Build{" "}
                <span className="bg-gradient-to-r from-blue-600 to-green-500 bg-clip-text text-transparent">
                  Professional Websites
                </span>{" "}
                from Scratch – No Coding Needed
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Master modern web design tools and create stunning websites that convert. Join thousands of students
                who've transformed their careers with our proven system.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  className="bg-green-500 hover:bg-green-600 text-white px-8 py-4 text-lg font-semibold shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all duration-200"
                  onClick={() => window.open("https://chat.whatsapp.com/E5Eg0Nnpawe6ISmai3kMdf", "_blank")}
                >
                  Start Learning Now
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="bg-white text-gray-700 border-gray-300 px-8 py-4 text-lg font-semibold hover:bg-gray-50"
                >
                  Watch Demo
                </Button>
              </div>

              {/* Stats */}
              <div className="flex items-center gap-8 mt-12">
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">5,000+</div>
                  <div className="text-sm text-gray-600">Students</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">4.9★</div>
                  <div className="text-sm text-gray-600">Rating</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">100%</div>
                  <div className="text-sm text-gray-600">Online</div>
                </div>
              </div>
            </div>

            {/* Right Content - 3D Laptop */}
            <div
              className={`transform transition-all duration-1000 delay-300 ${isVisible ? "translate-x-0 opacity-100" : "translate-x-10 opacity-0"}`}
            >
              <div className="relative">
                <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-t-3xl p-8 shadow-2xl transform skew-y-1 hover:skew-y-0 transition-transform duration-500">
                  <div className="bg-white rounded-lg p-6 shadow-inner transform -skew-y-1">
                    <div className="flex items-center gap-2 mb-4">
                      <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                      <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    </div>
                    <div className="space-y-3">
                      <div className="h-4 bg-blue-200 rounded w-3/4"></div>
                      <div className="h-4 bg-green-200 rounded w-1/2"></div>
                      <div className="h-8 bg-gradient-to-r from-blue-500 to-green-500 rounded"></div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="h-6 bg-gray-200 rounded"></div>
                        <div className="h-6 bg-gray-200 rounded"></div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="bg-gray-300 h-4 rounded-b-3xl shadow-lg transform skew-y-1"></div>

                {/* Floating elements around laptop */}
                <div className="absolute -top-4 -right-4 animate-bounce">
                  <div className="bg-blue-500 text-white p-2 rounded-full shadow-lg">
                    <Zap className="w-4 h-4" />
                  </div>
                </div>
                <div className="absolute -bottom-4 -left-4 animate-pulse">
                  <div className="bg-green-500 text-white p-2 rounded-full shadow-lg">
                    <Award className="w-4 h-4" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">About Website Training Bootcamp</h2>
            <p className="text-xl text-gray-600">Your Fast-Track to Website Mastery!</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-start mb-16">
            <div>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                At Website Training Bootcamp, we specialize in empowering beginners, business owners, freelancers, and
                aspiring web designers with the skills they need to create professional websites from scratch—without
                needing any coding experience.
              </p>
              <p className="text-lg text-gray-700 mb-8 leading-relaxed">
                Whether you're looking to build your first website, launch an online store, or start a career in web
                design, our intensive, beginner-friendly training will take you from zero to confident in just a few
                sessions.
              </p>

              {/* Mission */}
              <div className="mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">🎯 Our Mission</h3>
                <p className="text-gray-700 leading-relaxed">
                  Our mission is simple: to make website design training accessible, practical, and result-driven for
                  anyone who wants to learn. Through our hands-on lessons delivered via WhatsApp and other digital
                  platforms, we help you gain the confidence and skills to build beautiful, responsive websites.
                </p>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">💻 What We Offer</h3>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <Check className="w-6 h-6 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Step-by-step website training (even if you're a total beginner)</span>
                </li>
                <li className="flex items-start">
                  <Check className="w-6 h-6 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Live sessions and replays via WhatsApp</span>
                </li>
                <li className="flex items-start">
                  <Check className="w-6 h-6 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Practical projects and real-world assignments</span>
                </li>
                <li className="flex items-start">
                  <Check className="w-6 h-6 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Guidance on domain name, hosting, and launching your site</span>
                </li>
                <li className="flex items-start">
                  <Check className="w-6 h-6 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Support and mentorship from experienced designers</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Why Choose Us */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center flex items-center justify-center">
              🔑 Why Choose Website Training Bootcamp?
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="text-center p-6 hover:shadow-lg transition-shadow duration-300">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-8 h-8 text-blue-600" />
                </div>
                <h4 className="font-bold text-gray-900 mb-2">100% Practical</h4>
                <p className="text-sm text-gray-600">We believe in "learning by doing." Every lesson is hands-on.</p>
              </Card>

              <Card className="text-center p-6 hover:shadow-lg transition-shadow duration-300">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="w-8 h-8 text-green-600" />
                </div>
                <h4 className="font-bold text-gray-900 mb-2">Learn from Anywhere</h4>
                <p className="text-sm text-gray-600">Our WhatsApp training model makes it easy to learn on the go.</p>
              </Card>

              <Card className="text-center p-6 hover:shadow-lg transition-shadow duration-300">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-8 h-8 text-purple-600" />
                </div>
                <h4 className="font-bold text-gray-900 mb-2">No Prior Skills Needed</h4>
                <p className="text-sm text-gray-600">Start from scratch and build like a pro.</p>
              </Card>

              <Card className="text-center p-6 hover:shadow-lg transition-shadow duration-300">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-orange-600" />
                </div>
                <h4 className="font-bold text-gray-900 mb-2">Supportive Community</h4>
                <p className="text-sm text-gray-600">
                  Join a network of learners, designers, and online entrepreneurs.
                </p>
              </Card>
            </div>
          </div>

          {/* Who Is This For */}
          <div className="bg-gray-50 rounded-2xl p-8 mb-16">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center flex items-center justify-center">
              🚀 Who Is This Training For?
            </h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                  <span className="text-gray-700">Small business owners who want to build their own website</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                  <span className="text-gray-700">Aspiring web designers and freelancers</span>
                </div>
              </div>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                  <span className="text-gray-700">
                    Digital marketers who want to add website design to their skills
                  </span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                  <span className="text-gray-700">
                    Students and professionals looking for a side hustle or remote work skill
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="text-center bg-gradient-to-r from-blue-600 to-green-500 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">
              Join hundreds of others who are transforming their digital skills with Website Training Bootcamp.
            </h3>
            <p className="text-xl mb-6 opacity-90">It's time to take your ideas online and create something amazing.</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button
                size="lg"
                className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-3 font-semibold"
                onClick={() => window.open("https://chat.whatsapp.com/E5Eg0Nnpawe6ISmai3kMdf", "_blank")}
              >
                Enroll Now
              </Button>
              <div className="flex items-center gap-2">
                <span className="text-white/90">or Contact Us on WhatsApp:</span>
                <Button
                  variant="outline"
                  size="lg"
                  className="bg-transparent border-white text-white hover:bg-white hover:text-green-600 px-6 py-3 font-semibold"
                  onClick={() => window.open("https://wa.me/2349032473005", "_blank")}
                >
                  📱 09032473005
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Courses Section */}
      <section id="courses" className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Training Courses</h2>
            <p className="text-xl text-gray-600">
              Master multiple platforms and earn certificates in each specialization
            </p>
            <Badge className="mt-4 bg-green-100 text-green-700 text-lg px-4 py-2">🏆 Certificate Included</Badge>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {[
              {
                title: "Figma Design Training",
                description:
                  "Master professional UI/UX design with Figma. Learn to create stunning interfaces, prototypes, and design systems.",
                icon: "🎨",
                features: [
                  "Interface design fundamentals",
                  "Prototyping and animations",
                  "Design systems creation",
                  "Collaboration workflows",
                  "Mobile and web design",
                ],
                duration: "4 weeks",
                level: "Beginner to Advanced",
              },
              {
                title: "Wix Design Training",
                description:
                  "Build professional websites with Wix's drag-and-drop builder. Perfect for businesses and portfolios.",
                icon: "🌐",
                features: [
                  "Wix editor mastery",
                  "Custom templates creation",
                  "E-commerce setup",
                  "SEO optimization",
                  "Mobile responsiveness",
                ],
                duration: "3 weeks",
                level: "Beginner Friendly",
              },
              {
                title: "AI Programming",
                description:
                  "Learn to integrate AI tools and create intelligent applications. Future-proof your skills with AI technology.",
                icon: "🤖",
                features: [
                  "AI fundamentals",
                  "ChatGPT integration",
                  "AI-powered websites",
                  "Automation tools",
                  "Machine learning basics",
                ],
                duration: "6 weeks",
                level: "Intermediate",
              },
              {
                title: "Google Sites Design",
                description:
                  "Create professional websites using Google Sites. Perfect for businesses, portfolios, and team collaboration.",
                icon: "🏢",
                features: [
                  "Google Sites mastery",
                  "Custom layouts",
                  "Integration with Google Workspace",
                  "Team collaboration",
                  "Publishing and sharing",
                ],
                duration: "2 weeks",
                level: "Beginner",
              },
              {
                title: "WordPress Website Design",
                description:
                  "Master the world's most popular CMS. Build dynamic, professional websites with WordPress.",
                icon: "📝",
                features: [
                  "WordPress fundamentals",
                  "Theme customization",
                  "Plugin management",
                  "Content management",
                  "E-commerce with WooCommerce",
                ],
                duration: "5 weeks",
                level: "Beginner to Advanced",
              },
              {
                title: "Complete Web Design Bundle",
                description:
                  "Get access to all courses above plus exclusive bonuses. The ultimate web design training package.",
                icon: "🎯",
                features: [
                  "All 5 courses included",
                  "Priority WhatsApp support",
                  "1-on-1 mentoring sessions",
                  "Exclusive design resources",
                  "Lifetime course updates",
                ],
                duration: "12 weeks",
                level: "All Levels",
                popular: true,
              },
            ].map((course, index) => (
              <Card
                key={index}
                className={`relative ${course.popular ? "ring-2 ring-green-500 shadow-2xl scale-105" : "shadow-lg"} hover:shadow-xl transition-all duration-300 bg-white`}
              >
                {course.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-green-500 text-white">
                    Most Popular
                  </Badge>
                )}
                <CardHeader className="text-center pb-4">
                  <div className="text-4xl mb-4">{course.icon}</div>
                  <CardTitle className="text-xl font-bold text-gray-900 mb-2">{course.title}</CardTitle>
                  <p className="text-gray-600 text-sm leading-relaxed">{course.description}</p>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex justify-between items-center mb-4 text-sm">
                    <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full">{course.duration}</span>
                    <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full">{course.level}</span>
                  </div>

                  <h4 className="font-semibold text-gray-900 mb-3">What You'll Learn:</h4>
                  <ul className="space-y-2 mb-6">
                    {course.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start text-sm">
                        <Check className="w-4 h-4 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-600">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mb-4">
                    <div className="flex items-center text-sm text-yellow-800">
                      <Award className="w-4 h-4 mr-2" />
                      <span className="font-medium">Certificate of Completion Included</span>
                    </div>
                  </div>

                  <Button
                    className={`w-full ${course.popular ? "bg-green-500 hover:bg-green-600" : "bg-blue-600 hover:bg-blue-700"} text-white`}
                    size="lg"
                    onClick={() =>
                      window.open(
                        "https://wa.me/2349032473005?text=Hi! I'm interested in the " +
                          course.title +
                          " course. Can you tell me more about it?",
                        "_blank",
                      )
                    }
                  >
                    Enroll Now via WhatsApp
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Course Benefits */}
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Why Choose Our Courses?</h3>
            <div className="grid md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="w-8 h-8 text-green-600" />
                </div>
                <h4 className="font-bold text-gray-900 mb-2">WhatsApp Learning</h4>
                <p className="text-sm text-gray-600">
                  Learn directly through WhatsApp with instant support and feedback
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-8 h-8 text-blue-600" />
                </div>
                <h4 className="font-bold text-gray-900 mb-2">Certified Training</h4>
                <p className="text-sm text-gray-600">
                  Receive official certificates upon successful completion of each course
                </p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-purple-600" />
                </div>
                <h4 className="font-bold text-gray-900 mb-2">Expert Mentorship</h4>
                <p className="text-sm text-gray-600">Get guidance from experienced designers and developers</p>
              </div>

              <div className="text-center">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-8 h-8 text-orange-600" />
                </div>
                <h4 className="font-bold text-gray-900 mb-2">Hands-on Projects</h4>
                <p className="text-sm text-gray-600">Build real projects and create an impressive portfolio</p>
              </div>
            </div>
          </div>

          {/* Contact CTA */}
          <div className="text-center mt-12">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Ready to Start Your Journey?</h3>
            <p className="text-lg text-gray-600 mb-6">
              Contact us on WhatsApp to discuss which course is right for you
            </p>
            <Button
              size="lg"
              className="bg-green-500 hover:bg-green-600 text-white px-8 py-4 text-lg font-semibold"
              onClick={() =>
                window.open(
                  "https://wa.me/2349032473005?text=Hi! I'd like to know more about your training courses. Can you help me choose the right one?",
                  "_blank",
                )
              }
            >
              📱 Chat with Us - 09032473005
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">What Our Students Say</h2>
            <p className="text-xl text-gray-600">Join thousands of successful graduates</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                name: "Sarah O.",
                role: "Small Business Owner",
                content:
                  "I had zero tech skills before joining Website Training Bootcamp. Today, I proudly manage my business website myself. The training was clear, simple, and super practical. The WhatsApp format made it easy to follow at my own pace!",
                rating: 5,
                avatar: "SO",
              },
              {
                name: "James E.",
                role: "Freelancer",
                content:
                  "This bootcamp changed my life. I was struggling to find freelance gigs until I learned how to design websites. Now, I've completed 7 projects for clients and I'm earning consistently online. Best decision ever!",
                rating: 5,
                avatar: "JE",
              },
              {
                name: "Anita M.",
                role: "Student",
                content:
                  "As a student, I wanted to learn something useful during the holidays. The Website Training Bootcamp gave me real-world skills that I can use to build a side income. I already built my first portfolio site!",
                rating: 5,
                avatar: "AM",
              },
              {
                name: "Michael K.",
                role: "Aspiring Web Designer",
                content:
                  "The training was powerful. Step-by-step videos, real practice projects, and one-on-one feedback through WhatsApp. I never thought online learning could be this personal and effective.",
                rating: 5,
                avatar: "MK",
              },
              {
                name: "Grace T.",
                role: "Fashion Brand Owner",
                content:
                  "Hiring a web designer was expensive, so I decided to learn myself. In just one week, I created a stunning website for my fashion brand. Thank you Website Training Bootcamp – you saved me money and gave me confidence.",
                rating: 5,
                avatar: "GT",
              },
            ].map((testimonial, index) => (
              <Card
                key={index}
                className="bg-white shadow-lg hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-2"
              >
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-6 italic">"{testimonial.content}"</p>
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center text-white font-bold mr-4">
                      {testimonial.avatar}
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900">{testimonial.name}</div>
                      <div className="text-sm text-gray-600">{testimonial.role}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Choose Your Learning Path</h2>
            <p className="text-xl text-gray-600">Flexible pricing for every budget</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Starter",
                price: "$97",
                period: "one-time",
                features: ["8-week course access", "Basic templates", "Email support", "Certificate of completion"],
                popular: false,
              },
              {
                name: "Professional",
                price: "$197",
                period: "one-time",
                features: [
                  "Everything in Starter",
                  "Premium templates",
                  "WhatsApp support",
                  "1-on-1 mentoring session",
                  "Lifetime updates",
                ],
                popular: true,
              },
              {
                name: "Enterprise",
                price: "$397",
                period: "one-time",
                features: [
                  "Everything in Professional",
                  "Custom branding",
                  "Priority support",
                  "Monthly group calls",
                  "Business consultation",
                ],
                popular: false,
              },
            ].map((plan, index) => (
              <Card
                key={index}
                className={`relative ${plan.popular ? "ring-2 ring-green-500 shadow-2xl scale-105" : "shadow-lg"} hover:shadow-xl transition-all duration-300`}
              >
                {plan.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-green-500 text-white">
                    Most Popular
                  </Badge>
                )}
                <CardHeader className="text-center pb-8">
                  <CardTitle className="text-2xl font-bold text-gray-900">{plan.name}</CardTitle>
                  <div className="mt-4">
                    <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                    <span className="text-gray-600 ml-2">{plan.period}</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-4 mb-8">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center">
                        <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                        <span className="text-gray-600">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button
                    className={`w-full ${plan.popular ? "bg-green-500 hover:bg-green-600" : "bg-gray-900 hover:bg-gray-800"} text-white`}
                    size="lg"
                  >
                    Get Started
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* WhatsApp Training Section */}
      <section className="py-20 bg-gradient-to-br from-green-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Learn Through WhatsApp</h2>
              <p className="text-xl text-gray-600 mb-8">
                Get personalized guidance and instant support through our innovative WhatsApp-based learning system.
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <MessageCircle className="w-6 h-6 text-green-500 mr-3" />
                  <span className="text-gray-700">Daily lessons delivered to your phone</span>
                </div>
                <div className="flex items-center">
                  <Users className="w-6 h-6 text-green-500 mr-3" />
                  <span className="text-gray-700">Join our supportive community</span>
                </div>
                <div className="flex items-center">
                  <Clock className="w-6 h-6 text-green-500 mr-3" />
                  <span className="text-gray-700">Learn at your own pace</span>
                </div>
              </div>

              <Button
                size="lg"
                className="bg-green-500 hover:bg-green-600 text-white"
                onClick={() => window.open("https://chat.whatsapp.com/E5Eg0Nnpawe6ISmai3kMdf", "_blank")}
              >
                Join WhatsApp Training
              </Button>
            </div>

            <div className="relative">
              {/* WhatsApp Chat Mockup */}
              <div className="bg-white rounded-3xl shadow-2xl p-6 max-w-sm mx-auto">
                <div className="bg-green-500 text-white p-4 rounded-t-2xl -m-6 mb-6">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center mr-3">
                      <span className="text-sm font-bold">WB</span>
                    </div>
                    <div>
                      <div className="font-semibold">Website Bootcamp</div>
                      <div className="text-xs opacity-90">Online now</div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-gray-100 rounded-2xl rounded-tl-sm p-3 max-w-xs">
                    <p className="text-sm text-gray-800">
                      Welcome to Day 1! Today we'll learn about choosing the right platform for your website 🚀
                    </p>
                    <div className="text-xs text-gray-500 mt-1">9:00 AM</div>
                  </div>

                  <div className="bg-green-500 text-white rounded-2xl rounded-tr-sm p-3 max-w-xs ml-auto">
                    <p className="text-sm">Thanks! I'm excited to get started 😊</p>
                    <div className="text-xs opacity-75 mt-1">9:05 AM</div>
                  </div>

                  <div className="bg-gray-100 rounded-2xl rounded-tl-sm p-3 max-w-xs">
                    <p className="text-sm text-gray-800">
                      Perfect! Here's your first lesson video: "WordPress vs Wix - Which is Right for You?" 📹
                    </p>
                    <div className="text-xs text-gray-500 mt-1">9:10 AM</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Build Your First Website?</h2>
          <p className="text-xl text-gray-300 mb-8">
            Join thousands of students who've transformed their careers with our proven system.
          </p>
          <Button
            size="lg"
            className="bg-green-500 hover:bg-green-600 text-white px-12 py-4 text-lg font-semibold"
            onClick={() => window.open("https://chat.whatsapp.com/E5Eg0Nnpawe6ISmai3kMdf", "_blank")}
          >
            Start Learning Today
          </Button>
        </div>
      </section>
    </div>
  )
}
